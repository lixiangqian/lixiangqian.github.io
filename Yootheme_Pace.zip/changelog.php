<?php
/**
* @package   Pace
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

1.0.5
# Hide all dropdowns at first page load to prevent that they can be activated

1.0.4
# fixed bug if no dropdown is published and mode for vertical menu is 'diagonal'

1.0.3
+ Let the dropdown stay within the viewport if dropdown extends viewport

1.0.2
+ Added menu-aim plugin for vertical menu
+ Changed menu dropdown display effect to CSS3 transform

1.0.1
+ Added menubar width option. Width can now be set from the backend.

1.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note