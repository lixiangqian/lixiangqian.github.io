<?php

namespace YOOtheme\Widgetkit\Content;

interface ItemInterface extends \ArrayAccess
{
}
