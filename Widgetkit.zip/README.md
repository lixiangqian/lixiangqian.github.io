# YOOtheme Widgetkit

* [Homepage](http://yootheme.com)
* [Changelog](CHANGELOG.md)

## Copyright and license

Copyright 2015 [YOOtheme](http://yootheme.com) GmbH under the GPL license.
